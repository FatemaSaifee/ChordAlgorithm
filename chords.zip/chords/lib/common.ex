defmodule Common do

    @doc """
        Returns True if key is contained by [limit1,  limit2]
        Raise "oops" if limit1 == limit2
    """
    def isbetween(key, limit1, limit2) do
        
        if length(key) != length(limit1) != length(limit2) do
            raise "oops"
        end
        if key == limit1 or key == limit2 do
            true
        else
            if limit1 > limit2 do
                if key > limit1 or key < limit2 do
                    true
                else 
                    false
                end
            else 
                if limit1 < limit2 do
                    if key > limit1 and key < limit2 do
                        true
                    else
                        false
                    end
                else
                    # limit1 == limit2
                    raise "oops"
                end
            end
        end
    end
    
end
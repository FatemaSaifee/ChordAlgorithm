defmodule Chords do
  @moduledoc """
  Documentation for Chords.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Chords.hello()
      :world

  """
  def hello do
    :world
  end
end

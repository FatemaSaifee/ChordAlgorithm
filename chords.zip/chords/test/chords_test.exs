defmodule ChordsTest do
  use ExUnit.Case
  doctest Chords

  test "greets the world" do
    assert Chords.hello() == :world
  end
end
